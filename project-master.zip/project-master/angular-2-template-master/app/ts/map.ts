export class Map {
	startPosition: string;
	endPosition: string;

	constructor(startPosition: string, endPosition: string) {
		this.startPosition = startPosition;
		this.endPosition = endPosition;
	}
}