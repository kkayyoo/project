import {Component} from 'angular2/core';

@Component({
    selector: 'my-map',
    templateUrl: 'app/ts/map.component.html' 
})

export class MapComponent {
	
}